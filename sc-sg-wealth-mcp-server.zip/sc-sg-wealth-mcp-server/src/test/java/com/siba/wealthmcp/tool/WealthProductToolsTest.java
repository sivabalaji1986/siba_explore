package com.siba.wealthmcp.tool;

import com.siba.wealthmcp.config.WealthCatalogueProperties;
import com.siba.wealthmcp.domain.ProductNature;
import com.siba.wealthmcp.domain.ProductSource;
import com.siba.wealthmcp.domain.ProductStatus;
import com.siba.wealthmcp.domain.ProductType;
import com.siba.wealthmcp.domain.WealthCategory;
import com.siba.wealthmcp.domain.WealthProduct;
import com.siba.wealthmcp.service.WealthCatalogueService;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class WealthProductToolsTest {

    private final WealthProductTools tools = new WealthProductTools(
            new WealthCatalogueService(new WealthCatalogueProperties(List.of(
                    new WealthProduct(
                            "fixed-income",
                            "Fixed Income",
                            WealthCategory.INVESTMENT,
                            ProductNature.PRODUCT_FAMILY,
                            ProductType.FIXED_INCOME,
                            ProductStatus.ACTIVE,
                            "Debt securities",
                            List.of("Coupon income"),
                            List.of(),
                            "Varies",
                            "Issuer and market risk",
                            "See term sheet",
                            List.of("bonds", "income"),
                            new ProductSource("Fixed Income", "https://example.com/fixed-income", "2026-07-20"),
                            "Not financial advice")
            )))));

    @Test
    void exposesSearchAndSourceOperations() {
        assertThat(tools.searchWealthProducts("bonds"))
                .extracting(WealthProduct::productId)
                .containsExactly("fixed-income");

        assertThat(tools.getProductSource("fixed-income").source().url())
                .isEqualTo("https://example.com/fixed-income");
    }
}
