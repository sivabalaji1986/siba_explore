package com.siba.wealthmcp.service;

import com.siba.wealthmcp.config.WealthCatalogueProperties;
import com.siba.wealthmcp.domain.ProductNature;
import com.siba.wealthmcp.domain.ProductSource;
import com.siba.wealthmcp.domain.ProductStatus;
import com.siba.wealthmcp.domain.ProductType;
import com.siba.wealthmcp.domain.WealthCategory;
import com.siba.wealthmcp.domain.WealthProduct;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class WealthCatalogueServiceTest {

    private final WealthCatalogueService service = new WealthCatalogueService(
            new WealthCatalogueProperties(List.of(
                    product("unit-trusts", "Unit Trusts", WealthCategory.INVESTMENT, ProductType.MANAGED_FUNDS,
                            List.of("funds", "bonds", "equities")),
                    product("retirement", "Retirement Insurance", WealthCategory.INSURANCE, ProductType.RETIREMENT_INSURANCE,
                            List.of("retirement", "insurance", "income"))
            )));

    @Test
    void listsProductsUsingCaseInsensitiveFilters() {
        assertThat(service.listProducts("investment", "managed-funds"))
                .extracting(WealthProduct::productId)
                .containsExactly("unit-trusts");
    }

    @Test
    void searchesAcrossTagsAndDescriptions() {
        assertThat(service.search("income"))
                .extracting(WealthProduct::productId)
                .containsExactly("retirement");
    }

    @Test
    void getsProductByCaseInsensitiveId() {
        assertThat(service.getProduct("UNIT-TRUSTS").name()).isEqualTo("Unit Trusts");
    }

    @Test
    void rejectsUnknownFilterValuesWithAllowedValues() {
        assertThatThrownBy(() -> service.listProducts("unknown", null))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("Allowed values");
    }

    @Test
    void rejectsUnknownProductId() {
        assertThatThrownBy(() -> service.getProduct("missing"))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("No active wealth product");
    }

    private static WealthProduct product(
            String id,
            String name,
            WealthCategory category,
            ProductType type,
            List<String> tags) {
        return new WealthProduct(
                id,
                name,
                category,
                ProductNature.PRODUCT,
                type,
                ProductStatus.ACTIVE,
                name + " summary",
                List.of("feature"),
                List.of(),
                "varies",
                "risk",
                "provider",
                tags,
                new ProductSource("source", "https://example.com", "2026-07-20"),
                "disclaimer");
    }
}
