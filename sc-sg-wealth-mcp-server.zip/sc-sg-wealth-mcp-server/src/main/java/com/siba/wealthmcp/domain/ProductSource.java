package com.siba.wealthmcp.domain;

public record ProductSource(
        String title,
        String url,
        String lastVerifiedDate
) {
}
