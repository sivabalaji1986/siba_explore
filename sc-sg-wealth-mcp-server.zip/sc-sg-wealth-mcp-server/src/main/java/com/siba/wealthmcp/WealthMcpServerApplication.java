package com.siba.wealthmcp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;

@SpringBootApplication
@ConfigurationPropertiesScan
public class WealthMcpServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(WealthMcpServerApplication.class, args);
    }
}
