package com.siba.wealthmcp.service;

import com.siba.wealthmcp.config.WealthCatalogueProperties;
import com.siba.wealthmcp.domain.CategorySummary;
import com.siba.wealthmcp.domain.ProductSourceResponse;
import com.siba.wealthmcp.domain.ProductStatus;
import com.siba.wealthmcp.domain.ProductType;
import com.siba.wealthmcp.domain.WealthCategory;
import com.siba.wealthmcp.domain.WealthProduct;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.Arrays;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.Predicate;

@Service
public class WealthCatalogueService {

    private final List<WealthProduct> products;
    private final Map<String, WealthProduct> productsById;

    public WealthCatalogueService(WealthCatalogueProperties properties) {
        this.products = properties.products().stream()
                .sorted(Comparator.comparing(WealthProduct::name, String.CASE_INSENSITIVE_ORDER))
                .toList();
        this.productsById = this.products.stream()
                .collect(java.util.stream.Collectors.toUnmodifiableMap(
                        product -> normalize(product.productId()),
                        product -> product));

        if (productsById.size() != products.size()) {
            throw new IllegalStateException("Duplicate wealth product IDs are not allowed");
        }
    }

    public List<CategorySummary> listCategories() {
        Map<WealthCategory, Long> counts = new EnumMap<>(WealthCategory.class);
        for (WealthCategory category : WealthCategory.values()) {
            counts.put(category, 0L);
        }
        products.stream()
                .filter(product -> product.status() != ProductStatus.ARCHIVED)
                .forEach(product -> counts.compute(product.category(), (key, value) -> value + 1));

        return counts.entrySet().stream()
                .map(entry -> new CategorySummary(entry.getKey(), entry.getValue()))
                .toList();
    }

    public List<WealthProduct> listProducts(String category, String productType) {
        Predicate<WealthProduct> categoryFilter = categoryFilter(category);
        Predicate<WealthProduct> typeFilter = productTypeFilter(productType);

        return products.stream()
                .filter(product -> product.status() != ProductStatus.ARCHIVED)
                .filter(categoryFilter)
                .filter(typeFilter)
                .toList();
    }

    public WealthProduct getProduct(String productId) {
        if (!StringUtils.hasText(productId)) {
            throw new IllegalArgumentException("productId is required");
        }
        WealthProduct product = productsById.get(normalize(productId));
        if (product == null || product.status() == ProductStatus.ARCHIVED) {
            throw new IllegalArgumentException("No active wealth product found for productId: " + productId);
        }
        return product;
    }

    public List<WealthProduct> search(String query) {
        if (!StringUtils.hasText(query)) {
            throw new IllegalArgumentException("query is required");
        }
        String normalizedQuery = normalize(query);

        return products.stream()
                .filter(product -> product.status() != ProductStatus.ARCHIVED)
                .filter(product -> searchableText(product).contains(normalizedQuery))
                .toList();
    }

    public ProductSourceResponse getProductSource(String productId) {
        WealthProduct product = getProduct(productId);
        return new ProductSourceResponse(
                product.productId(),
                product.name(),
                product.status(),
                product.source(),
                product.disclaimer());
    }

    private Predicate<WealthProduct> categoryFilter(String category) {
        if (!StringUtils.hasText(category)) {
            return product -> true;
        }
        WealthCategory parsed = parseEnum(WealthCategory.class, category, "category");
        return product -> product.category() == parsed;
    }

    private Predicate<WealthProduct> productTypeFilter(String productType) {
        if (!StringUtils.hasText(productType)) {
            return product -> true;
        }
        ProductType parsed = parseEnum(ProductType.class, productType, "productType");
        return product -> product.productType() == parsed;
    }

    private String searchableText(WealthProduct product) {
        return normalize(String.join(" ",
                product.productId(),
                product.name(),
                product.category().name(),
                product.nature().name(),
                product.productType().name(),
                product.summary(),
                String.join(" ", product.features()),
                String.join(" ", product.eligibilityNotes()),
                product.minimumInvestment() == null ? "" : product.minimumInvestment(),
                product.riskStatement() == null ? "" : product.riskStatement(),
                product.providerNote() == null ? "" : product.providerNote(),
                String.join(" ", product.tags())));
    }

    private static <E extends Enum<E>> E parseEnum(Class<E> enumType, String value, String fieldName) {
        String normalized = value.trim().toUpperCase(Locale.ROOT).replace('-', '_').replace(' ', '_');
        try {
            return Enum.valueOf(enumType, normalized);
        }
        catch (IllegalArgumentException exception) {
            String allowed = Arrays.stream(enumType.getEnumConstants())
                    .map(Enum::name)
                    .collect(java.util.stream.Collectors.joining(", "));
            throw new IllegalArgumentException(
                    "Invalid " + fieldName + " '" + value + "'. Allowed values: " + allowed);
        }
    }

    private static String normalize(String value) {
        return value == null ? "" : value.toLowerCase(Locale.ROOT).trim();
    }
}
