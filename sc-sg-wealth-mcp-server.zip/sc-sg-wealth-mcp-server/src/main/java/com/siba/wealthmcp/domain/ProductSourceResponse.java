package com.siba.wealthmcp.domain;

public record ProductSourceResponse(
        String productId,
        String productName,
        ProductStatus status,
        ProductSource source,
        String disclaimer
) {
}
