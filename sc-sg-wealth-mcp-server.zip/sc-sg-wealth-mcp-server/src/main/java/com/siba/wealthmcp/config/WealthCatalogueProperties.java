package com.siba.wealthmcp.config;

import com.siba.wealthmcp.domain.WealthProduct;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.List;

@ConfigurationProperties(prefix = "wealth.catalogue")
public record WealthCatalogueProperties(List<WealthProduct> products) {

    public WealthCatalogueProperties {
        products = products == null ? List.of() : List.copyOf(products);
    }
}
