package com.siba.wealthmcp.tool;

import com.siba.wealthmcp.domain.CategorySummary;
import com.siba.wealthmcp.domain.ProductSourceResponse;
import com.siba.wealthmcp.domain.WealthProduct;
import com.siba.wealthmcp.service.WealthCatalogueService;
import org.springframework.ai.mcp.annotation.McpTool;
import org.springframework.ai.mcp.annotation.McpToolParam;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class WealthProductTools {

    private final WealthCatalogueService catalogueService;

    public WealthProductTools(WealthCatalogueService catalogueService) {
        this.catalogueService = catalogueService;
    }

    @McpTool(
            name = "list_wealth_categories",
            description = "List the available Standard Chartered Singapore wealth catalogue categories and the number of active entries in each category."
    )
    public List<CategorySummary> listWealthCategories() {
        return catalogueService.listCategories();
    }

    @McpTool(
            name = "list_wealth_products",
            description = "List public Standard Chartered Singapore wealth products and services. Optionally filter by category and product type. This tool provides factual catalogue information only, not financial advice."
    )
    public List<WealthProduct> listWealthProducts(
            @McpToolParam(
                    description = "Optional category: INVESTMENT, INSURANCE, FINANCING or ADVISORY_SERVICE.",
                    required = false
            ) String category,
            @McpToolParam(
                    description = "Optional product type, for example MANAGED_FUNDS, DIGITAL_PORTFOLIO, FIXED_INCOME or SAVINGS_INSURANCE.",
                    required = false
            ) String productType) {
        return catalogueService.listProducts(category, productType);
    }

    @McpTool(
            name = "get_wealth_product",
            description = "Get the curated details, risks, eligibility notes, official source and verification date for one wealth catalogue entry."
    )
    public WealthProduct getWealthProduct(
            @McpToolParam(description = "The stable product ID returned by list_wealth_products.", required = true)
            String productId) {
        return catalogueService.getProduct(productId);
    }

    @McpTool(
            name = "search_wealth_products",
            description = "Search the wealth catalogue using plain-language terms such as retirement, equities, foreign exchange, income, legacy, sustainable or lending."
    )
    public List<WealthProduct> searchWealthProducts(
            @McpToolParam(description = "Search text. Matching is case-insensitive across names, summaries, features and tags.", required = true)
            String query) {
        return catalogueService.search(query);
    }

    @McpTool(
            name = "get_product_source",
            description = "Return the official Standard Chartered Singapore source page and last verification date for one catalogue entry."
    )
    public ProductSourceResponse getProductSource(
            @McpToolParam(description = "The stable product ID returned by list_wealth_products.", required = true)
            String productId) {
        return catalogueService.getProductSource(productId);
    }
}
