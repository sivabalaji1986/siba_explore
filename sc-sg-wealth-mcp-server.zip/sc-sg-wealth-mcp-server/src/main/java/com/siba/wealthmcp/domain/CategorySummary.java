package com.siba.wealthmcp.domain;

public record CategorySummary(
        WealthCategory category,
        long productCount
) {
}
