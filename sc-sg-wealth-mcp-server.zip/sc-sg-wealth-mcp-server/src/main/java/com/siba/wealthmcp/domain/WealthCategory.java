package com.siba.wealthmcp.domain;

public enum WealthCategory {
    INVESTMENT,
    INSURANCE,
    FINANCING,
    ADVISORY_SERVICE
}
