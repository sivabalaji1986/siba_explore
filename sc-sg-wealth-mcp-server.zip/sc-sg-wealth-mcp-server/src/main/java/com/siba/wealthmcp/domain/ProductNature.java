package com.siba.wealthmcp.domain;

public enum ProductNature {
    PRODUCT,
    PRODUCT_FAMILY,
    SERVICE,
    ADVISORY_FRAMEWORK,
    INVESTMENT_THEME
}
