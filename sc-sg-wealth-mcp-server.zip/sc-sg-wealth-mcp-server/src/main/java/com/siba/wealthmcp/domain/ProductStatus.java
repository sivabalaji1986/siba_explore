package com.siba.wealthmcp.domain;

public enum ProductStatus {
    ACTIVE,
    VERIFY_BEFORE_USE,
    ARCHIVED
}
