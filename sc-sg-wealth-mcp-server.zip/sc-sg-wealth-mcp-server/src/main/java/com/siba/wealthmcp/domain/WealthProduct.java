package com.siba.wealthmcp.domain;

import java.util.List;

public record WealthProduct(
        String productId,
        String name,
        WealthCategory category,
        ProductNature nature,
        ProductType productType,
        ProductStatus status,
        String summary,
        List<String> features,
        List<String> eligibilityNotes,
        String minimumInvestment,
        String riskStatement,
        String providerNote,
        List<String> tags,
        ProductSource source,
        String disclaimer
) {
    public WealthProduct {
        features = immutable(features);
        eligibilityNotes = immutable(eligibilityNotes);
        tags = immutable(tags);
    }

    private static List<String> immutable(List<String> values) {
        return values == null ? List.of() : List.copyOf(values);
    }
}
