# Standard Chartered Singapore Wealth MCP Server

A read-only Model Context Protocol (MCP) server that exposes a curated catalogue of publicly available Standard Chartered Singapore wealth products, product families and advisory services.

> This is a technical demonstration built from public web information. It is not an official Standard Chartered service, does not access bank systems, and does not provide financial advice.

## Technology

- Java 21
- Spring Boot 4.1.0
- Spring AI 2.0.0
- Spring AI MCP Server WebMVC starter
- MCP Streamable HTTP transport
- Maven

No LLM provider or API key is required. The consuming MCP host contains the LLM; this server only exposes deterministic tools.

## What is exposed

| MCP tool | Purpose |
|---|---|
| `list_wealth_categories` | List catalogue categories and entry counts |
| `list_wealth_products` | List products, optionally filtered by category and product type |
| `get_wealth_product` | Retrieve one complete catalogue entry |
| `search_wealth_products` | Search names, descriptions, features and tags |
| `get_product_source` | Return the official source URL and verification date |

## Architecture

```mermaid
flowchart LR
    A[MCP client / AI assistant] -->|Streamable HTTP| B[Spring AI MCP server]
    B --> C[WealthProductTools]
    C --> D[WealthCatalogueService]
    D --> E[Curated application.yml catalogue]
```

## Catalogue design

Every entry contains:

- Stable product ID
- Category, nature and type
- Summary and features
- Eligibility notes
- Minimum-investment wording where safely available
- Risk statement
- Provider/distributor note
- Official source URL
- Last verification date
- Financial-information disclaimer

Temporary promotions, live rates and personalised recommendations are deliberately excluded.

## Build and run

Requirements:

- JDK 21
- Maven 3.6.3 or newer

```bash
mvn clean verify
mvn spring-boot:run
```

The MCP endpoint is:

```text
http://localhost:8080/mcp
```

The health endpoint is:

```text
http://localhost:8080/actuator/health
```

## Build and run with Docker

```bash
mvn clean package

docker build -t sc-sg-wealth-mcp-server .
docker run --rm -p 8080:8080 sc-sg-wealth-mcp-server
```

## Example tool calls

### List all entries

Tool: `list_wealth_products`

```json
{
  "category": null,
  "productType": null
}
```

### Filter investment products

Tool: `list_wealth_products`

```json
{
  "category": "INVESTMENT",
  "productType": null
}
```

### Search for retirement-related entries

Tool: `search_wealth_products`

```json
{
  "query": "retirement"
}
```

### Get one product

Tool: `get_wealth_product`

```json
{
  "productId": "fixed-income"
}
```

## Valid filter values

Categories:

- `INVESTMENT`
- `INSURANCE`
- `FINANCING`
- `ADVISORY_SERVICE`

Product types:

- `MANAGED_FUNDS`
- `DIGITAL_PORTFOLIO`
- `SECURITIES_TRADING`
- `FOREIGN_EXCHANGE`
- `FIXED_INCOME`
- `STRUCTURED_PRODUCT`
- `SECURED_LENDING`
- `INVESTMENT_PLANNING`
- `SUSTAINABLE_INVESTING`
- `WEALTH_ADVISORY`
- `SAVINGS_INSURANCE`
- `LEGACY_INSURANCE`
- `RETIREMENT_INSURANCE`

The tool also accepts spaces and hyphens, for example `fixed-income` or `fixed income`.

## Important production improvements

Before using this pattern in an enterprise environment:

1. Add OAuth 2.1/resource-server protection and authorisation policies.
2. Move catalogue approval into a governed content-management workflow.
3. Add an automated link and freshness checker, but require human approval before publishing changes.
4. Record catalogue version, approver and change history.
5. Add schema-level MCP contract tests using an MCP client.
6. Add rate limiting, audit logging and observability.
7. Replace demonstration wording with legally approved product descriptions and disclaimers.

## Official references used for the seed catalogue

- Standard Chartered Singapore Wealth Management: https://www.sc.com/sg/wealth/
- Online Unit Trusts: https://www.sc.com/sg/wealth/investment/unit-trusts/
- Online Trading: https://www.sc.com/sg/wealth/investment/online-trading/
- LiveFX: https://www.sc.com/sg/investment/livefx/
- SC Invest: https://www.sc.com/sg/wealth/investment/sc-invest/
- Fixed Income: https://www.sc.com/sg/wealth/investment/fixedincome/
- Structured Deposits: https://www.sc.com/sg/wealth/investment/structured-deposits/
- Wealth Lending: https://www.sc.com/sg/wealth/investment/secured-wealth-lending/
- myWealth Advisor: https://www.sc.com/sg/wealth/mywealth-advisor/
- Sustainable Investing: https://www.sc.com/sg/wealth/sustainable-investing/
- SC Wealth Select: https://www.sc.com/sg/wealth/sc-wealth-select/
- Insurance Savings Plans: https://www.sc.com/sg/insurance/insurance-savings-plan/
- Legacy Insurance: https://www.sc.com/sg/insurance/legacy/
- Retirement Insurance: https://www.sc.com/sg/insurance/retirement/

Seed content was last reviewed on **20 July 2026**. Always re-check the official pages before production use.
