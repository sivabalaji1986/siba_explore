# Mock Customer Onboarding MCP Server

A small Java 21, Spring Boot 4 and Spring AI MCP server for a larger customer-onboarding demo.

It exposes exactly two tools:

- `create_relationship`
- `create_account`

There are no downstream APIs and no database. Relationships and accounts are stored in memory, and all generated values reset when the application restarts.

## Technology

- Java 21
- Spring Boot 4.1.0
- Spring AI 2.0.0
- Spring MVC Streamable HTTP MCP transport
- Maven
- JUnit 5

## Build and run

```bash
mvn clean verify
mvn spring-boot:run
```

The MCP endpoint is:

```text
http://localhost:8080/mcp
```

Use any MCP client that supports Streamable HTTP, or connect through the MCP Inspector.

## Tool 1: `create_relationship`

Arguments:

```json
{
  "firstName": "Arun",
  "lastName": "Kumar",
  "dateOfBirth": "1988-06-15",
  "nationality": "SG",
  "identityType": "NRIC",
  "identityNumber": "SXXXX123A",
  "mobileNumber": "91234567",
  "emailAddress": "customer@example.com"
}
```

Example result:

```json
{
  "success": true,
  "relationshipId": "REL000001",
  "customerName": "Arun Kumar",
  "status": "CREATED",
  "createdAt": "2026-07-20T10:30:45Z",
  "message": "Relationship created successfully."
}
```

## Tool 2: `create_account`

Call this only after `create_relationship` returns a valid Relationship ID.

Arguments:

```json
{
  "relationshipId": "REL000001",
  "productCode": "SG-SAVINGS-001",
  "accountType": "SAVINGS",
  "currency": "SGD",
  "accountName": "Arun Kumar"
}
```

Example result:

```json
{
  "success": true,
  "relationshipId": "REL000001",
  "accountId": "ACC000001",
  "accountNumber": "1000000001",
  "productCode": "SG-SAVINGS-001",
  "accountType": "SAVINGS",
  "currency": "SGD",
  "status": "OPEN",
  "createdAt": "2026-07-20T10:35:10Z",
  "message": "Account created successfully."
}
```

Unknown Relationship ID:

```json
{
  "success": false,
  "relationshipId": "REL999999",
  "errorCode": "RELATIONSHIP_NOT_FOUND",
  "message": "The supplied Relationship ID does not exist."
}
```

## Running sequences

Configured in `src/main/resources/application.yml`:

```yaml
mock:
  sequence:
    relationship-start: 1
    account-start: 1
    account-number-start: 1000000001
```

Generated values:

```text
REL000001, REL000002, ...
ACC000001, ACC000002, ...
1000000001, 1000000002, ...
```

The three sequences are independent and thread-safe.

## In-memory data

The server uses:

```text
ConcurrentHashMap<String, Relationship>
ConcurrentHashMap<String, Account>
```

Data and sequences reset after every application restart.

## Logging

Operations are logged to the console and to:

```text
logs/customer-onboarding-mcp.log
```

The identity number is masked before it is logged.

## Project structure

```text
src/main/java/com/siba/onboardingmcp/
├── config
├── model
├── repository
├── service
└── tool
```

## Tests

The tests cover:

- Sequential Relationship IDs
- Sequential Account IDs and account numbers
- Relationship creation
- Account creation under an existing relationship
- Rejection of an unknown Relationship ID
- Input validation
- Identity-number masking
- MCP tool contract: exactly two tools

Run:

```bash
mvn test
```

## Intentionally out of scope

- Downstream REST APIs
- Database persistence
- Authentication and authorisation
- KYC/AML processing
- Idempotency
- Retry and circuit breakers
- Customer or account retrieval tools
