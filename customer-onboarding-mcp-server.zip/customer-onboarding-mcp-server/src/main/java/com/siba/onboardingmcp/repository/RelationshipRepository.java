package com.siba.onboardingmcp.repository;

import java.time.Instant;
import java.time.LocalDate;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.AtomicLong;

import com.siba.onboardingmcp.config.MockSequenceProperties;
import com.siba.onboardingmcp.model.Relationship;
import org.springframework.stereotype.Repository;

@Repository
public class RelationshipRepository {

    private final ConcurrentMap<String, Relationship> relationships = new ConcurrentHashMap<>();
    private final AtomicLong relationshipSequence;

    public RelationshipRepository(MockSequenceProperties properties) {
        this.relationshipSequence = new AtomicLong(properties.relationshipStart());
    }

    public Relationship create(
            String firstName,
            String lastName,
            LocalDate dateOfBirth,
            String nationality,
            String identityType,
            String identityNumber,
            String mobileNumber,
            String emailAddress,
            Instant createdAt) {

        String relationshipId = "REL%06d".formatted(relationshipSequence.getAndIncrement());
        Relationship relationship = new Relationship(
                relationshipId,
                firstName,
                lastName,
                dateOfBirth,
                nationality,
                identityType,
                identityNumber,
                mobileNumber,
                emailAddress,
                createdAt);
        relationships.put(relationshipId, relationship);
        return relationship;
    }

    public Optional<Relationship> findById(String relationshipId) {
        return Optional.ofNullable(relationships.get(relationshipId));
    }

    public int size() {
        return relationships.size();
    }
}
