package com.siba.onboardingmcp.service;

import java.time.Clock;
import java.time.Instant;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.Locale;

import com.siba.onboardingmcp.model.CreateRelationshipRequest;
import com.siba.onboardingmcp.model.CreateRelationshipResponse;
import com.siba.onboardingmcp.model.Relationship;
import com.siba.onboardingmcp.repository.RelationshipRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class RelationshipService {

    private static final Logger log = LoggerFactory.getLogger(RelationshipService.class);

    private final RelationshipRepository relationshipRepository;
    private final Clock clock;

    public RelationshipService(RelationshipRepository relationshipRepository, Clock clock) {
        this.relationshipRepository = relationshipRepository;
        this.clock = clock;
    }

    public CreateRelationshipResponse createRelationship(CreateRelationshipRequest request) {
        try {
            String firstName = InputValidation.required(request.firstName(), "firstName");
            String lastName = InputValidation.required(request.lastName(), "lastName");
            LocalDate dateOfBirth = parseDateOfBirth(request.dateOfBirth());
            String nationality = InputValidation.twoLetterCode(request.nationality(), "nationality");
            String identityType = InputValidation.required(request.identityType(), "identityType").toUpperCase(Locale.ROOT);
            String identityNumber = InputValidation.required(request.identityNumber(), "identityNumber");
            String mobileNumber = InputValidation.optional(request.mobileNumber());
            String emailAddress = InputValidation.email(request.emailAddress());
            Instant createdAt = clock.instant();

            Relationship relationship = relationshipRepository.create(
                    firstName,
                    lastName,
                    dateOfBirth,
                    nationality,
                    identityType,
                    identityNumber,
                    mobileNumber,
                    emailAddress,
                    createdAt);

            log.info(
                    "Relationship created: relationshipId={}, customerName={} {}, identityNumber={}",
                    relationship.relationshipId(),
                    firstName,
                    lastName,
                    maskIdentityNumber(identityNumber));

            return CreateRelationshipResponse.created(relationship);
        }
        catch (IllegalArgumentException ex) {
            log.warn("Relationship creation rejected: {}", ex.getMessage());
            return CreateRelationshipResponse.failed("VALIDATION_ERROR", ex.getMessage());
        }
    }

    private LocalDate parseDateOfBirth(String value) {
        String normalized = InputValidation.required(value, "dateOfBirth");
        try {
            LocalDate dateOfBirth = LocalDate.parse(normalized);
            if (!dateOfBirth.isBefore(LocalDate.now(clock))) {
                throw new IllegalArgumentException("dateOfBirth must be a date in the past.");
            }
            return dateOfBirth;
        }
        catch (DateTimeParseException ex) {
            throw new IllegalArgumentException("dateOfBirth must use ISO format yyyy-MM-dd.");
        }
    }

    static String maskIdentityNumber(String identityNumber) {
        if (identityNumber == null || identityNumber.isBlank()) {
            return "***";
        }
        if (identityNumber.length() <= 4) {
            return "*".repeat(identityNumber.length());
        }
        return identityNumber.substring(0, 1)
                + "*".repeat(identityNumber.length() - 3)
                + identityNumber.substring(identityNumber.length() - 2);
    }
}
