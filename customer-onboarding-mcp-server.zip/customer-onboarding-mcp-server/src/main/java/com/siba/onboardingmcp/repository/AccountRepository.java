package com.siba.onboardingmcp.repository;

import java.time.Instant;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.AtomicLong;

import com.siba.onboardingmcp.config.MockSequenceProperties;
import com.siba.onboardingmcp.model.Account;
import org.springframework.stereotype.Repository;

@Repository
public class AccountRepository {

    private final ConcurrentMap<String, Account> accounts = new ConcurrentHashMap<>();
    private final AtomicLong accountSequence;
    private final AtomicLong accountNumberSequence;

    public AccountRepository(MockSequenceProperties properties) {
        this.accountSequence = new AtomicLong(properties.accountStart());
        this.accountNumberSequence = new AtomicLong(properties.accountNumberStart());
    }

    public Account create(
            String relationshipId,
            String productCode,
            String accountType,
            String currency,
            String accountName,
            Instant createdAt) {

        String accountId = "ACC%06d".formatted(accountSequence.getAndIncrement());
        String accountNumber = Long.toString(accountNumberSequence.getAndIncrement());
        Account account = new Account(
                accountId,
                accountNumber,
                relationshipId,
                productCode,
                accountType,
                currency,
                accountName,
                "OPEN",
                createdAt);
        accounts.put(accountId, account);
        return account;
    }

    public Optional<Account> findById(String accountId) {
        return Optional.ofNullable(accounts.get(accountId));
    }

    public int size() {
        return accounts.size();
    }
}
