package com.siba.onboardingmcp.model;

public record CreateRelationshipRequest(
        String firstName,
        String lastName,
        String dateOfBirth,
        String nationality,
        String identityType,
        String identityNumber,
        String mobileNumber,
        String emailAddress) {
}
