package com.siba.onboardingmcp.model;

public record CreateAccountRequest(
        String relationshipId,
        String productCode,
        String accountType,
        String currency,
        String accountName) {
}
