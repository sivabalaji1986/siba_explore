package com.siba.onboardingmcp.model;

import java.time.Instant;
import java.time.LocalDate;

public record Relationship(
        String relationshipId,
        String firstName,
        String lastName,
        LocalDate dateOfBirth,
        String nationality,
        String identityType,
        String identityNumber,
        String mobileNumber,
        String emailAddress,
        Instant createdAt) {
}
