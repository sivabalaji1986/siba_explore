package com.siba.onboardingmcp.service;

import java.time.Clock;
import java.time.Instant;
import java.util.Locale;

import com.siba.onboardingmcp.model.Account;
import com.siba.onboardingmcp.model.CreateAccountRequest;
import com.siba.onboardingmcp.model.CreateAccountResponse;
import com.siba.onboardingmcp.repository.AccountRepository;
import com.siba.onboardingmcp.repository.RelationshipRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class AccountService {

    private static final Logger log = LoggerFactory.getLogger(AccountService.class);

    private final RelationshipRepository relationshipRepository;
    private final AccountRepository accountRepository;
    private final Clock clock;

    public AccountService(
            RelationshipRepository relationshipRepository,
            AccountRepository accountRepository,
            Clock clock) {
        this.relationshipRepository = relationshipRepository;
        this.accountRepository = accountRepository;
        this.clock = clock;
    }

    public CreateAccountResponse createAccount(CreateAccountRequest request) {
        String relationshipId = request.relationshipId();
        try {
            relationshipId = InputValidation.required(relationshipId, "relationshipId").toUpperCase(Locale.ROOT);
            String productCode = InputValidation.required(request.productCode(), "productCode").toUpperCase(Locale.ROOT);
            String accountType = InputValidation.required(request.accountType(), "accountType").toUpperCase(Locale.ROOT);
            String currency = InputValidation.threeLetterCode(request.currency(), "currency");
            String accountName = InputValidation.required(request.accountName(), "accountName");

            if (relationshipRepository.findById(relationshipId).isEmpty()) {
                log.warn("Account creation rejected: relationshipId={} not found", relationshipId);
                return CreateAccountResponse.failed(
                        relationshipId,
                        "RELATIONSHIP_NOT_FOUND",
                        "The supplied Relationship ID does not exist.");
            }

            Instant createdAt = clock.instant();
            Account account = accountRepository.create(
                    relationshipId,
                    productCode,
                    accountType,
                    currency,
                    accountName,
                    createdAt);

            log.info(
                    "Account created: accountId={}, relationshipId={}, productCode={}",
                    account.accountId(),
                    account.relationshipId(),
                    account.productCode());

            return CreateAccountResponse.opened(account);
        }
        catch (IllegalArgumentException ex) {
            log.warn("Account creation rejected: {}", ex.getMessage());
            return CreateAccountResponse.failed(relationshipId, "VALIDATION_ERROR", ex.getMessage());
        }
    }
}
