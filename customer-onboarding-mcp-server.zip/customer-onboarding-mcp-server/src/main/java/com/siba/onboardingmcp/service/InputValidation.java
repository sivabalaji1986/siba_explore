package com.siba.onboardingmcp.service;

import java.util.Locale;
import java.util.regex.Pattern;

final class InputValidation {

    private static final Pattern EMAIL_PATTERN =
            Pattern.compile("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$");
    private static final Pattern TWO_LETTER_CODE = Pattern.compile("^[A-Za-z]{2}$");
    private static final Pattern THREE_LETTER_CODE = Pattern.compile("^[A-Za-z]{3}$");

    private InputValidation() {
    }

    static String required(String value, String fieldName) {
        if (value == null || value.isBlank()) {
            throw new IllegalArgumentException(fieldName + " must not be blank.");
        }
        return value.trim();
    }

    static String optional(String value) {
        return value == null || value.isBlank() ? null : value.trim();
    }

    static String twoLetterCode(String value, String fieldName) {
        String normalized = required(value, fieldName).toUpperCase(Locale.ROOT);
        if (!TWO_LETTER_CODE.matcher(normalized).matches()) {
            throw new IllegalArgumentException(fieldName + " must be a two-letter code.");
        }
        return normalized;
    }

    static String threeLetterCode(String value, String fieldName) {
        String normalized = required(value, fieldName).toUpperCase(Locale.ROOT);
        if (!THREE_LETTER_CODE.matcher(normalized).matches()) {
            throw new IllegalArgumentException(fieldName + " must be a three-letter code.");
        }
        return normalized;
    }

    static String email(String value) {
        String normalized = optional(value);
        if (normalized != null && !EMAIL_PATTERN.matcher(normalized).matches()) {
            throw new IllegalArgumentException("emailAddress must be a valid email address.");
        }
        return normalized;
    }
}
