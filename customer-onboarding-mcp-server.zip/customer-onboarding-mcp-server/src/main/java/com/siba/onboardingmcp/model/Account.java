package com.siba.onboardingmcp.model;

import java.time.Instant;

public record Account(
        String accountId,
        String accountNumber,
        String relationshipId,
        String productCode,
        String accountType,
        String currency,
        String accountName,
        String status,
        Instant createdAt) {
}
