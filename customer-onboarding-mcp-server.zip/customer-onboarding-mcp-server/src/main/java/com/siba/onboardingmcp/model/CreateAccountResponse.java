package com.siba.onboardingmcp.model;

import java.time.Instant;


public record CreateAccountResponse(
        boolean success,
        String relationshipId,
        String accountId,
        String accountNumber,
        String productCode,
        String accountType,
        String currency,
        String status,
        Instant createdAt,
        String errorCode,
        String message) {

    public static CreateAccountResponse opened(Account account) {
        return new CreateAccountResponse(
                true,
                account.relationshipId(),
                account.accountId(),
                account.accountNumber(),
                account.productCode(),
                account.accountType(),
                account.currency(),
                account.status(),
                account.createdAt(),
                null,
                "Account created successfully.");
    }

    public static CreateAccountResponse failed(
            String relationshipId,
            String errorCode,
            String message) {
        return new CreateAccountResponse(
                false,
                relationshipId,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                errorCode,
                message);
    }
}
