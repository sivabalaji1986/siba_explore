package com.siba.onboardingmcp.tool;

import com.siba.onboardingmcp.model.CreateAccountRequest;
import com.siba.onboardingmcp.model.CreateAccountResponse;
import com.siba.onboardingmcp.model.CreateRelationshipRequest;
import com.siba.onboardingmcp.model.CreateRelationshipResponse;
import com.siba.onboardingmcp.service.AccountService;
import com.siba.onboardingmcp.service.RelationshipService;
import org.springframework.ai.mcp.annotation.McpTool;
import org.springframework.ai.mcp.annotation.McpToolParam;
import org.springframework.stereotype.Component;

@Component
public class CustomerOnboardingTools {

    private final RelationshipService relationshipService;
    private final AccountService accountService;

    public CustomerOnboardingTools(
            RelationshipService relationshipService,
            AccountService accountService) {
        this.relationshipService = relationshipService;
        this.accountService = accountService;
    }

    @McpTool(
            name = "create_relationship",
            title = "Create Customer Relationship",
            description = "Creates a mock customer relationship and returns a sequential Relationship ID.",
            generateOutputSchema = true,
            annotations = @McpTool.McpAnnotations(
                    title = "Create Customer Relationship",
                    readOnlyHint = false,
                    destructiveHint = false,
                    idempotentHint = false,
                    openWorldHint = false))
    public CreateRelationshipResponse createRelationship(
            @McpToolParam(description = "Customer first name", required = true)
            String firstName,
            @McpToolParam(description = "Customer last name", required = true)
            String lastName,
            @McpToolParam(description = "Date of birth in yyyy-MM-dd format", required = true)
            String dateOfBirth,
            @McpToolParam(description = "Two-letter nationality code, for example SG", required = true)
            String nationality,
            @McpToolParam(description = "Identity type, for example NRIC or PASSPORT", required = true)
            String identityType,
            @McpToolParam(description = "Mock customer identity number", required = true)
            String identityNumber,
            @McpToolParam(description = "Optional mobile number", required = false)
            String mobileNumber,
            @McpToolParam(description = "Optional email address", required = false)
            String emailAddress) {

        return relationshipService.createRelationship(new CreateRelationshipRequest(
                firstName,
                lastName,
                dateOfBirth,
                nationality,
                identityType,
                identityNumber,
                mobileNumber,
                emailAddress));
    }

    @McpTool(
            name = "create_account",
            title = "Create Customer Account",
            description = "Creates a mock account under an existing mock Relationship ID.",
            generateOutputSchema = true,
            annotations = @McpTool.McpAnnotations(
                    title = "Create Customer Account",
                    readOnlyHint = false,
                    destructiveHint = false,
                    idempotentHint = false,
                    openWorldHint = false))
    public CreateAccountResponse createAccount(
            @McpToolParam(description = "Existing Relationship ID, for example REL000001", required = true)
            String relationshipId,
            @McpToolParam(description = "Mock product code, for example SG-SAVINGS-001", required = true)
            String productCode,
            @McpToolParam(description = "Account type, for example SAVINGS", required = true)
            String accountType,
            @McpToolParam(description = "Three-letter currency code, for example SGD", required = true)
            String currency,
            @McpToolParam(description = "Name to place on the mock account", required = true)
            String accountName) {

        return accountService.createAccount(new CreateAccountRequest(
                relationshipId,
                productCode,
                accountType,
                currency,
                accountName));
    }
}
