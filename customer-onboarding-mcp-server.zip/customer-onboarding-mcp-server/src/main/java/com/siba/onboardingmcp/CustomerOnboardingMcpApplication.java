package com.siba.onboardingmcp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;

@SpringBootApplication
@ConfigurationPropertiesScan
public class CustomerOnboardingMcpApplication {

    public static void main(String[] args) {
        SpringApplication.run(CustomerOnboardingMcpApplication.class, args);
    }
}
