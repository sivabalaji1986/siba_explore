package com.siba.onboardingmcp.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "mock.sequence")
public record MockSequenceProperties(
        long relationshipStart,
        long accountStart,
        long accountNumberStart) {

    public MockSequenceProperties {
        if (relationshipStart < 1) {
            throw new IllegalArgumentException("mock.sequence.relationship-start must be at least 1");
        }
        if (accountStart < 1) {
            throw new IllegalArgumentException("mock.sequence.account-start must be at least 1");
        }
        if (accountNumberStart < 1) {
            throw new IllegalArgumentException("mock.sequence.account-number-start must be at least 1");
        }
    }
}
