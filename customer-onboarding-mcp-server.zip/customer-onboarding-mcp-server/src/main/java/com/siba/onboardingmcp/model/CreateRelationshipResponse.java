package com.siba.onboardingmcp.model;

import java.time.Instant;


public record CreateRelationshipResponse(
        boolean success,
        String relationshipId,
        String customerName,
        String status,
        Instant createdAt,
        String errorCode,
        String message) {

    public static CreateRelationshipResponse created(Relationship relationship) {
        return new CreateRelationshipResponse(
                true,
                relationship.relationshipId(),
                relationship.firstName() + " " + relationship.lastName(),
                "CREATED",
                relationship.createdAt(),
                null,
                "Relationship created successfully.");
    }

    public static CreateRelationshipResponse failed(String errorCode, String message) {
        return new CreateRelationshipResponse(
                false,
                null,
                null,
                null,
                null,
                errorCode,
                message);
    }
}
