package com.siba.onboardingmcp.tool;

import static org.assertj.core.api.Assertions.assertThat;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Set;
import java.util.stream.Collectors;

import org.junit.jupiter.api.Test;
import org.springframework.ai.mcp.annotation.McpTool;

class CustomerOnboardingToolsContractTest {

    @Test
    void exposesExactlyTwoMcpTools() {
        Set<String> toolNames = Arrays.stream(CustomerOnboardingTools.class.getDeclaredMethods())
                .map(method -> method.getAnnotation(McpTool.class))
                .filter(annotation -> annotation != null)
                .map(McpTool::name)
                .collect(Collectors.toSet());

        assertThat(toolNames).containsExactlyInAnyOrder(
                "create_relationship",
                "create_account");
    }

    @Test
    void marksBothToolsAsStructuredOutputTools() {
        for (Method method : CustomerOnboardingTools.class.getDeclaredMethods()) {
            McpTool annotation = method.getAnnotation(McpTool.class);
            if (annotation != null) {
                assertThat(annotation.generateOutputSchema()).isTrue();
            }
        }
    }
}
