package com.siba.onboardingmcp.repository;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.Instant;
import java.time.LocalDate;

import com.siba.onboardingmcp.config.MockSequenceProperties;
import org.junit.jupiter.api.Test;

class RelationshipRepositoryTest {

    @Test
    void generatesSequentialRelationshipIds() {
        RelationshipRepository repository = new RelationshipRepository(
                new MockSequenceProperties(1, 1, 1_000_000_001L));

        var first = repository.create(
                "Arun", "Kumar", LocalDate.of(1988, 6, 15), "SG",
                "NRIC", "SXXXX123A", null, null, Instant.EPOCH);
        var second = repository.create(
                "Meera", "Nair", LocalDate.of(1990, 1, 2), "SG",
                "NRIC", "SXXXX456B", null, null, Instant.EPOCH);

        assertThat(first.relationshipId()).isEqualTo("REL000001");
        assertThat(second.relationshipId()).isEqualTo("REL000002");
        assertThat(repository.size()).isEqualTo(2);
    }
}
