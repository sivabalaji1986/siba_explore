package com.siba.onboardingmcp.repository;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.Instant;

import com.siba.onboardingmcp.config.MockSequenceProperties;
import org.junit.jupiter.api.Test;

class AccountRepositoryTest {

    @Test
    void generatesSequentialAccountIdsAndNumbers() {
        AccountRepository repository = new AccountRepository(
                new MockSequenceProperties(1, 1, 1_000_000_001L));

        var first = repository.create(
                "REL000001", "SG-SAVINGS-001", "SAVINGS", "SGD", "Arun Kumar", Instant.EPOCH);
        var second = repository.create(
                "REL000001", "SG-CURRENT-001", "CURRENT", "SGD", "Arun Kumar", Instant.EPOCH);

        assertThat(first.accountId()).isEqualTo("ACC000001");
        assertThat(first.accountNumber()).isEqualTo("1000000001");
        assertThat(second.accountId()).isEqualTo("ACC000002");
        assertThat(second.accountNumber()).isEqualTo("1000000002");
        assertThat(repository.size()).isEqualTo(2);
    }
}
