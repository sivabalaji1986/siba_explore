package com.siba.onboardingmcp.service;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.Clock;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneOffset;

import com.siba.onboardingmcp.config.MockSequenceProperties;
import com.siba.onboardingmcp.model.CreateAccountRequest;
import com.siba.onboardingmcp.repository.AccountRepository;
import com.siba.onboardingmcp.repository.RelationshipRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class AccountServiceTest {

    private RelationshipRepository relationshipRepository;
    private AccountService service;

    @BeforeEach
    void setUp() {
        var properties = new MockSequenceProperties(1, 1, 1_000_000_001L);
        relationshipRepository = new RelationshipRepository(properties);
        var accountRepository = new AccountRepository(properties);
        var clock = Clock.fixed(Instant.parse("2026-07-20T10:35:10Z"), ZoneOffset.UTC);
        service = new AccountService(relationshipRepository, accountRepository, clock);
    }

    @Test
    void createsAccountForExistingRelationship() {
        var relationship = relationshipRepository.create(
                "Arun", "Kumar", LocalDate.of(1988, 6, 15), "SG", "NRIC",
                "SXXXX123A", null, null, Instant.parse("2026-07-20T10:30:45Z"));

        var response = service.createAccount(new CreateAccountRequest(
                relationship.relationshipId(), "SG-SAVINGS-001", "SAVINGS", "sgd", "Arun Kumar"));

        assertThat(response.success()).isTrue();
        assertThat(response.relationshipId()).isEqualTo("REL000001");
        assertThat(response.accountId()).isEqualTo("ACC000001");
        assertThat(response.accountNumber()).isEqualTo("1000000001");
        assertThat(response.status()).isEqualTo("OPEN");
    }

    @Test
    void rejectsUnknownRelationship() {
        var response = service.createAccount(new CreateAccountRequest(
                "REL999999", "SG-SAVINGS-001", "SAVINGS", "SGD", "Arun Kumar"));

        assertThat(response.success()).isFalse();
        assertThat(response.errorCode()).isEqualTo("RELATIONSHIP_NOT_FOUND");
    }
}
