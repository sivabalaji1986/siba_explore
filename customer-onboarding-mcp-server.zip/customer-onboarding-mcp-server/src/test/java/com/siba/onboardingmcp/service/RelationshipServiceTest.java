package com.siba.onboardingmcp.service;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;

import com.siba.onboardingmcp.config.MockSequenceProperties;
import com.siba.onboardingmcp.model.CreateRelationshipRequest;
import com.siba.onboardingmcp.repository.RelationshipRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class RelationshipServiceTest {

    private RelationshipService service;

    @BeforeEach
    void setUp() {
        var properties = new MockSequenceProperties(1, 1, 1_000_000_001L);
        var repository = new RelationshipRepository(properties);
        var clock = Clock.fixed(Instant.parse("2026-07-20T10:30:45Z"), ZoneOffset.UTC);
        service = new RelationshipService(repository, clock);
    }

    @Test
    void createsRelationship() {
        var response = service.createRelationship(new CreateRelationshipRequest(
                "Arun", "Kumar", "1988-06-15", "sg", "NRIC",
                "SXXXX123A", "91234567", "customer@example.com"));

        assertThat(response.success()).isTrue();
        assertThat(response.relationshipId()).isEqualTo("REL000001");
        assertThat(response.status()).isEqualTo("CREATED");
        assertThat(response.createdAt()).isEqualTo(Instant.parse("2026-07-20T10:30:45Z"));
    }

    @Test
    void rejectsFutureDateOfBirth() {
        var response = service.createRelationship(new CreateRelationshipRequest(
                "Arun", "Kumar", "2027-01-01", "SG", "NRIC",
                "SXXXX123A", null, null));

        assertThat(response.success()).isFalse();
        assertThat(response.errorCode()).isEqualTo("VALIDATION_ERROR");
    }

    @Test
    void masksIdentityNumberForLogs() {
        assertThat(RelationshipService.maskIdentityNumber("SXXXX123A")).isEqualTo("S******3A");
    }
}
